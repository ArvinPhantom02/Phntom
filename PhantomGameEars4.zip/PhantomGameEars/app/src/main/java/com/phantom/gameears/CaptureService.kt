package com.phantom.gameears

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Bitmap
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Handler
import android.os.HandlerThread
import android.os.IBinder
import android.os.Looper
import android.provider.Settings
import android.graphics.Color
import android.view.WindowManager
import android.os.SystemClock
import android.util.DisplayMetrics
import android.view.Display
import androidx.core.app.NotificationCompat
import com.google.mediapipe.framework.image.BitmapImageBuilder
import com.google.mediapipe.tasks.core.BaseOptions
import com.google.mediapipe.tasks.vision.core.RunningMode
import com.google.mediapipe.tasks.vision.objectdetector.ObjectDetector
import kotlin.math.max

/** صفحهٔ گوشی (بازی) را زنده می‌گیرد، اشیا را پیدا می‌کند و با صدا و بوق جهت‌دار اعلام می‌کند. */
class CaptureService : Service() {

    companion object {
        const val ACTION_START = "com.phantom.gameears.START"
        const val ACTION_STOP = "com.phantom.gameears.STOP"
        const val EXTRA_CODE = "code"
        const val EXTRA_DATA = "data"
        const val MODEL_FILE = "efficientdet_lite0.tflite"
        private const val CHANNEL = "ears_channel"
        private const val NOTIF_ID = 7
        private const val MAX_SIDE = 640
        private const val FRAME_GAP_MS = 220L
        private const val REPEAT_GAP_MS = 3000L

        @Volatile var running = false
        @Volatile var lastError: String? = null
    }

    private data class Item(
        val cls: String, val x: Float, val y: Float, val h: Int, val v: Int, val area: Float,
        val l: Float, val t: Float, val r: Float, val b: Float
    )

    private lateinit var prefs: Prefs
    private val thread = HandlerThread("ears-capture").apply { start() }
    private lateinit var handler: Handler

    private var projection: MediaProjection? = null
    private var display: VirtualDisplay? = null
    private var reader: ImageReader? = null
    private var detector: ObjectDetector? = null
    private var speaker: Speaker? = null
    private var beeper: Beeper? = null

    private var capW = 0
    private var capH = 0
    private var dpi = 320
    private var lastProcess = 0L
    private var lastSizeCheck = 0L
    private var stopping = false
    private val lastSpoken = HashMap<String, Long>()

    private val listener = ImageReader.OnImageAvailableListener { onFrame(it) }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        prefs = Prefs(this)
        handler = Handler(thread.looper)
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        nm.createNotificationChannel(NotificationChannel(CHANNEL, "Phantom Ears", NotificationManager.IMPORTANCE_LOW))
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_STOP -> { stopAll(); return START_NOT_STICKY }
            ACTION_START -> {
                if (running) return START_NOT_STICKY
                startInForeground()
                val code = intent.getIntExtra(EXTRA_CODE, 0)
                @Suppress("DEPRECATION")
                val data: Intent? = if (Build.VERSION.SDK_INT >= 33)
                    intent.getParcelableExtra(EXTRA_DATA, Intent::class.java)
                else intent.getParcelableExtra(EXTRA_DATA)
                if (data == null) {
                    lastError = "اجازهٔ ضبط صفحه دریافت نشد"
                    stopAll()
                    return START_NOT_STICKY
                }
                lastError = null
                try {
                    startCapture(code, data)
                } catch (e: Exception) {
                    lastError = "خطا در شروع: " + (e.message ?: e.javaClass.simpleName)
                    stopAll()
                }
                return START_NOT_STICKY
            }
            else -> { stopSelf(); return START_NOT_STICKY }
        }
    }

    private fun startInForeground() {
        val stopIntent = PendingIntent.getService(
            this, 1,
            Intent(this, CaptureService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val n: Notification = NotificationCompat.Builder(this, CHANNEL)
            .setSmallIcon(android.R.drawable.ic_media_play)
            .setContentTitle("Phantom Ears")
            .setContentText("صفحه در حال نگهبانی است")
            .setOngoing(true)
            .addAction(android.R.drawable.ic_media_pause, "توقف", stopIntent)
            .build()
        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(NOTIF_ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION)
        } else {
            startForeground(NOTIF_ID, n)
        }
    }

    @Suppress("DEPRECATION")
    private fun realSize(): Pair<Int, Int> {
        val dm = DisplayMetrics()
        val d = (getSystemService(Context.DISPLAY_SERVICE) as DisplayManager).getDisplay(Display.DEFAULT_DISPLAY)
        d.getRealMetrics(dm)
        dpi = dm.densityDpi
        return dm.widthPixels to dm.heightPixels
    }

    private fun scaled(w: Int, h: Int): Pair<Int, Int> {
        val s = MAX_SIDE.toFloat() / max(w, h)
        val cw = ((w * s).toInt() / 2 * 2).coerceAtLeast(2)
        val ch = ((h * s).toInt() / 2 * 2).coerceAtLeast(2)
        return cw to ch
    }

    private fun startCapture(code: Int, data: Intent) {
        val mpm = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        val p = mpm.getMediaProjection(code, data) ?: throw IllegalStateException("projection")
        projection = p
        p.registerCallback(object : MediaProjection.Callback() {
            override fun onStop() { stopAll() }
        }, handler)

        detector = ObjectDetector.createFromOptions(
            this,
            ObjectDetector.ObjectDetectorOptions.builder()
                .setBaseOptions(BaseOptions.builder().setModelAssetPath(MODEL_FILE).build())
                .setRunningMode(RunningMode.IMAGE)
                .setMaxResults(20)
                .setScoreThreshold(0.2f)
                .build()
        )
        speaker = Speaker(this) { persian ->
            speaker?.speak(if (persian) "نگهبانی صفحه شروع شد" else "Screen watch started")
        }
        beeper = Beeper(handler)

        val (w, h) = realSize()
        val (cw, ch) = scaled(w, h)
        capW = cw
        capH = ch
        val r = ImageReader.newInstance(capW, capH, PixelFormat.RGBA_8888, 2)
        r.setOnImageAvailableListener(listener, handler)
        reader = r
        display = p.createVirtualDisplay(
            "ears", capW, capH, dpi,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR, r.surface, null, handler
        )
        running = true
    }

    private fun onFrame(r: ImageReader) {
        val img = try { r.acquireLatestImage() } catch (e: Exception) { null } ?: return
        try {
            val now = SystemClock.uptimeMillis()
            if (now - lastProcess >= FRAME_GAP_MS) {
                lastProcess = now
                val plane = img.planes[0]
                val rowPadding = plane.rowStride - plane.pixelStride * img.width
                val full = Bitmap.createBitmap(
                    img.width + rowPadding / plane.pixelStride, img.height, Bitmap.Config.ARGB_8888
                )
                full.copyPixelsFromBuffer(plane.buffer)
                val bmp = if (rowPadding == 0) full else Bitmap.createBitmap(full, 0, 0, img.width, img.height)
                detect(bmp)
            }
        } catch (_: Exception) {
        } finally {
            img.close()
        }
        checkSize()
    }

    /** اگر جهت صفحه عوض شد (عمودی/افقی) اندازهٔ ضبط را به‌روز می‌کند. */
    private fun checkSize() {
        val now = SystemClock.uptimeMillis()
        if (now - lastSizeCheck < 1000) return
        lastSizeCheck = now
        try {
            val (w, h) = realSize()
            val (cw, ch) = scaled(w, h)
            if (cw != capW || ch != capH) {
                capW = cw
                capH = ch
                val old = reader
                val nr = ImageReader.newInstance(capW, capH, PixelFormat.RGBA_8888, 2)
                nr.setOnImageAvailableListener(listener, handler)
                display?.resize(capW, capH, dpi)
                display?.surface = nr.surface
                reader = nr
                old?.close()
            }
        } catch (_: Exception) {
        }
    }

    private fun detect(bmp: Bitmap) {
        val det = detector ?: return
        val res = det.detect(BitmapImageBuilder(bmp).build())
        val w = bmp.width.toFloat()
        val h = bmp.height.toFloat()
        val th = prefs.threshold
        val sel = prefs.selected
        val items = res.detections().mapNotNull { d ->
            val c = d.categories().firstOrNull() ?: return@mapNotNull null
            if (c.score() < th || c.categoryName() !in sel) return@mapNotNull null
            val b = d.boundingBox()
            val x = (b.centerX() / w).coerceIn(0f, 1f)
            val y = (b.centerY() / h).coerceIn(0f, 1f)
            val hh = if (x < 0.33f) 0 else if (x > 0.67f) 2 else 1
            val vv = if (y < 0.33f) 0 else if (y > 0.67f) 2 else 1
            Item(
                c.categoryName(), x, y, hh, vv, (b.width() * b.height()) / (w * h),
                (b.left / w).coerceIn(0f, 1f), (b.top / h).coerceIn(0f, 1f),
                (b.right / w).coerceIn(0f, 1f), (b.bottom / h).coerceIn(0f, 1f)
            )
        }
        announce(items)
    }

    private fun posWord(h: Int, v: Int, fa: Boolean): String {
        if (h == 1 && v == 1) return if (fa) "وسط" else "center"
        val hw = when (h) { 0 -> if (fa) "چپ" else "left"; 2 -> if (fa) "راست" else "right"; else -> null }
        val vw = when (v) { 0 -> if (fa) "بالا" else "top"; 2 -> if (fa) "پایین" else "bottom"; else -> null }
        return listOfNotNull(hw, vw).joinToString(" ")
    }

    private fun announce(items: List<Item>) {
        if (items.isEmpty()) return
        val now = SystemClock.uptimeMillis()
        val fa = speaker?.persian ?: true
        val groups = items.groupBy { it.cls + "|" + it.h + it.v }
        val ready = groups.entries
            .filter { now - (lastSpoken[it.key] ?: 0L) > REPEAT_GAP_MS }
            .sortedByDescending { e -> e.value.maxOf { it.area } }
            .take(2)
        if (ready.isEmpty()) return
        val parts = ArrayList<String>()
        for (e in ready) {
            lastSpoken[e.key] = now
            val first = e.value.first()
            if (prefs.beep) beeper?.beep(first.x, first.y)
            val label = if (fa) CocoClasses.fa(first.cls) else first.cls
            val n = e.value.size
            val sep = if (fa) "، " else ", "
            parts.add((if (n > 1) "$n " else "") + label + sep + posWord(first.h, first.v, fa))
        }
        val sp = speaker
        if (prefs.speak && sp != null && !sp.isBusy()) {
            sp.speak(parts.joinToString(if (fa) "، " else ", "))
        }
    }

    @Synchronized
    private fun stopAll() {
        if (stopping) return
        stopping = true
        running = false
        try { reader?.setOnImageAvailableListener(null, null) } catch (_: Exception) {}
        try { display?.release() } catch (_: Exception) {}
        try { reader?.close() } catch (_: Exception) {}
        try { projection?.stop() } catch (_: Exception) {}
        try { detector?.close() } catch (_: Exception) {}
        try { speaker?.shutdown() } catch (_: Exception) {}
        display = null
        reader = null
        projection = null
        detector = null
        speaker = null
        thread.quitSafely()
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    override fun onDestroy() {
        running = false
        super.onDestroy()
    }
}
