package com.phantom.gameears

import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioTrack
import android.os.Handler
import kotlin.math.PI
import kotlin.math.min
import kotlin.math.sin
import kotlin.math.sqrt

/** بوق کوتاه استریو: x (۰=چپ تا ۱=راست) جهت صدا را می‌سازد، y (۰=بالا تا ۱=پایین) زیر و بمی را. */
class Beeper(private val handler: Handler) {
    fun beep(x: Float, y: Float) {
        try {
            val rate = 22050
            val n = (rate * 0.14).toInt()
            val freq = 1300.0 - 700.0 * y.coerceIn(0f, 1f)
            val pan = (x.coerceIn(0f, 1f) * 2f - 1f)
            val l = sqrt(((1f - pan) / 2f).toDouble())
            val r = sqrt(((1f + pan) / 2f).toDouble())
            val fade = rate * 0.01
            val buf = ShortArray(n * 2)
            for (i in 0 until n) {
                val e = min(1.0, min(i.toDouble(), (n - i).toDouble()) / fade)
                val v = sin(2 * PI * freq * i / rate) * e * 0.9
                buf[2 * i] = (v * l * Short.MAX_VALUE).toInt().toShort()
                buf[2 * i + 1] = (v * r * Short.MAX_VALUE).toInt().toShort()
            }
            val t = AudioTrack.Builder()
                .setAudioAttributes(
                    AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_ASSISTANCE_ACCESSIBILITY)
                        .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                        .build()
                )
                .setAudioFormat(
                    AudioFormat.Builder()
                        .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                        .setSampleRate(rate)
                        .setChannelMask(AudioFormat.CHANNEL_OUT_STEREO)
                        .build()
                )
                .setBufferSizeInBytes(buf.size * 2)
                .setTransferMode(AudioTrack.MODE_STATIC)
                .build()
            t.write(buf, 0, buf.size)
            t.play()
            handler.postDelayed({ try { t.release() } catch (_: Exception) {} }, 500)
        } catch (_: Exception) {
        }
    }
}
