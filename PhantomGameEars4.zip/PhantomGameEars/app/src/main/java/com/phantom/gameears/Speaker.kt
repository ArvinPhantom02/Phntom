package com.phantom.gameears

import android.content.Context
import android.media.AudioAttributes
import android.speech.tts.TextToSpeech
import java.util.Locale

/** گوینده: اگر صدای فارسی روی گوشی باشد فارسی، وگرنه انگلیسی. */
class Speaker(ctx: Context, private val onReady: ((Boolean) -> Unit)? = null) {
    private var ready = false
    var persian = false
        private set
    private lateinit var tts: TextToSpeech

    init {
        tts = TextToSpeech(ctx.applicationContext) { status ->
            if (status == TextToSpeech.SUCCESS) {
                val r = tts.setLanguage(Locale("fa", "IR"))
                persian = r != TextToSpeech.LANG_MISSING_DATA && r != TextToSpeech.LANG_NOT_SUPPORTED
                if (!persian) tts.setLanguage(Locale.US)
                tts.setAudioAttributes(
                    AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_ASSISTANCE_ACCESSIBILITY)
                        .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                        .build()
                )
                ready = true
                onReady?.invoke(persian)
            }
        }
    }

    fun isBusy(): Boolean = ready && tts.isSpeaking

    fun speak(text: String) {
        if (ready) tts.speak(text, TextToSpeech.QUEUE_FLUSH, null, "ears")
    }

    fun shutdown() {
        try { tts.stop(); tts.shutdown() } catch (_: Exception) {}
    }
}
