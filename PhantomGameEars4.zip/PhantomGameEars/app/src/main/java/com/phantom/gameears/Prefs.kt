package com.phantom.gameears

import android.content.Context

class Prefs(ctx: Context) {
    private val sp = ctx.getSharedPreferences("ears_prefs", Context.MODE_PRIVATE)

    var selected: Set<String>
        get() = sp.getStringSet("selected", setOf("person", "airplane"))!!.toSet()
        set(v) { sp.edit().putStringSet("selected", v).apply() }

    var threshold: Float
        get() = sp.getFloat("threshold", 0.4f)
        set(v) { sp.edit().putFloat("threshold", v).apply() }

    var speak: Boolean
        get() = sp.getBoolean("speak", true)
        set(v) { sp.edit().putBoolean("speak", v).apply() }

    var boxes: Boolean
        get() = sp.getBoolean("boxes", false)
        set(v) { sp.edit().putBoolean("boxes", v).apply() }

    var beep: Boolean
        get() = sp.getBoolean("beep", true)
        set(v) { sp.edit().putBoolean("beep", v).apply() }
}
