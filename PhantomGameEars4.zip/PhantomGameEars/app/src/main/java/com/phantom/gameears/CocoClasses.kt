package com.phantom.gameears

object CocoClasses {
    val NAMES = listOf(
        "person", "bicycle", "car", "motorcycle", "airplane", "bus", "train", "truck", "boat", "traffic light",
        "fire hydrant", "stop sign", "parking meter", "bench", "bird", "cat", "dog", "horse", "sheep", "cow",
        "elephant", "bear", "zebra", "giraffe", "backpack", "umbrella", "handbag", "tie", "suitcase", "frisbee",
        "skis", "snowboard", "sports ball", "kite", "baseball bat", "baseball glove", "skateboard", "surfboard", "tennis racket", "bottle",
        "wine glass", "cup", "fork", "knife", "spoon", "bowl", "banana", "apple", "sandwich", "orange",
        "broccoli", "carrot", "hot dog", "pizza", "donut", "cake", "chair", "couch", "potted plant", "bed",
        "dining table", "toilet", "tv", "laptop", "mouse", "remote", "keyboard", "cell phone", "microwave", "oven",
        "toaster", "sink", "refrigerator", "book", "clock", "vase", "scissors", "teddy bear", "hair drier", "toothbrush"
    )
    private val FA = listOf(
        "فرد", "دوچرخه", "ماشین", "موتورسیکلت", "هواپیما", "اتوبوس", "قطار", "کامیون", "قایق", "چراغ راهنما",
        "شیر آتش‌نشانی", "علامت ایست", "پارک‌سنج", "نیمکت", "پرنده", "گربه", "سگ", "اسب", "گوسفند", "گاو",
        "فیل", "خرس", "گورخر", "زرافه", "کوله‌پشتی", "چتر", "کیف دستی", "کراوات", "چمدان", "فریزبی",
        "اسکی", "اسنوبورد", "توپ ورزشی", "بادبادک", "چوب بیسبال", "دستکش بیسبال", "اسکیت‌برد", "موج‌سوار", "راکت تنیس", "بطری",
        "لیوان شراب", "فنجان", "چنگال", "چاقو", "قاشق", "کاسه", "موز", "سیب", "ساندویچ", "پرتقال",
        "بروکلی", "هویج", "هات‌داگ", "پیتزا", "دونات", "کیک", "صندلی", "مبل", "گیاه گلدانی", "تخت",
        "میز غذاخوری", "توالت", "تلویزیون", "لپ‌تاپ", "ماوس", "کنترل", "کیبورد", "گوشی موبایل", "مایکروویو", "فر",
        "توستر", "سینک", "یخچال", "کتاب", "ساعت", "گلدان", "قیچی", "خرس عروسکی", "سشوار", "مسواک"
    )
    private val map = NAMES.zip(FA).toMap()
    fun fa(name: String): String = map[name] ?: name
}
