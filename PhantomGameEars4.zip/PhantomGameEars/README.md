# Phantom Ears
صفحهٔ بازی را زنده می‌بیند و با صدا و بوق جهت‌دار می‌گوید فرد/هواپیما/... کجاست.
مدل تشخیص (efficientdet_lite0.tflite) باید در app/src/main/assets/ باشد (در ساخت GitHub خودکار دانلود می‌شود).
