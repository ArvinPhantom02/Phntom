package com.phantom.gameears

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Build
import android.provider.Settings
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.widget.Button
import android.widget.CheckBox
import android.widget.SeekBar
import android.widget.TextView
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat

class MainActivity : AppCompatActivity() {

    private lateinit var prefs: Prefs
    private lateinit var btnToggle: Button
    private lateinit var tvStatus: TextView
    private lateinit var tvSens: TextView
    private val handler = Handler(Looper.getMainLooper())
    private var testSpeaker: Speaker? = null

    private val projLauncher = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
        val data = r.data
        if (r.resultCode == Activity.RESULT_OK && data != null) {
            val i = Intent(this, CaptureService::class.java)
                .setAction(CaptureService.ACTION_START)
                .putExtra(CaptureService.EXTRA_CODE, r.resultCode)
                .putExtra(CaptureService.EXTRA_DATA, data)
            ContextCompat.startForegroundService(this, i)
            handler.postDelayed({ refresh() }, 900)
        } else {
            tvStatus.text = "اجازهٔ ضبط صفحه داده نشد"
        }
    }

    private val notifLauncher = registerForActivityResult(ActivityResultContracts.RequestPermission()) {
        askProjection()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        prefs = Prefs(this)
        btnToggle = findViewById(R.id.btnToggle)
        tvStatus = findViewById(R.id.tvStatus)
        tvSens = findViewById(R.id.tvSens)
        val cbSpeak = findViewById<CheckBox>(R.id.cbSpeak)
        val cbBeep = findViewById<CheckBox>(R.id.cbBeep)
        val cbBox = findViewById<CheckBox>(R.id.cbBox)
        val seek = findViewById<SeekBar>(R.id.seekSens)

        cbSpeak.isChecked = prefs.speak
        cbBeep.isChecked = prefs.beep
        cbBox.isChecked = prefs.boxes
        cbBox.setOnCheckedChangeListener { _, c -> prefs.boxes = c }
        cbSpeak.setOnCheckedChangeListener { _, c -> prefs.speak = c }
        cbBeep.setOnCheckedChangeListener { _, c -> prefs.beep = c }

        seek.progress = ((prefs.threshold - 0.2f) * 100f).toInt().coerceIn(0, 60)
        updateSensText(seek.progress)
        seek.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) {
                prefs.threshold = 0.2f + p / 100f
                updateSensText(p)
            }
            override fun onStartTrackingTouch(s: SeekBar?) {}
            override fun onStopTrackingTouch(s: SeekBar?) {}
        })

        btnToggle.setOnClickListener { toggle() }
        findViewById<Button>(R.id.btnSelect).setOnClickListener { showSelection() }
        findViewById<Button>(R.id.btnTest).setOnClickListener { runTest() }
    }

    override fun onResume() {
        super.onResume()
        refresh()
    }

    override fun onDestroy() {
        testSpeaker?.shutdown()
        handler.removeCallbacksAndMessages(null)
        super.onDestroy()
    }

    private fun updateSensText(p: Int) {
        tvSens.text = "حساسیت تشخیص: ${(0.2f + p / 100f)} (عدد کمتر = تشخیص بیشتر ولی اشتباه بیشتر)"
    }

    private fun refresh() {
        if (CaptureService.running) {
            btnToggle.text = "توقف نگهبانی صفحه"
            tvStatus.text = "فعال است. حالا بازی را باز کنید."
        } else {
            btnToggle.text = "شروع نگهبانی صفحه"
            tvStatus.text = CaptureService.lastError ?: "غیرفعال"
        }
    }

    private fun toggle() {
        if (CaptureService.running) {
            startService(Intent(this, CaptureService::class.java).setAction(CaptureService.ACTION_STOP))
            handler.postDelayed({ refresh() }, 600)
        } else if (prefs.boxes && !Settings.canDrawOverlays(this)) {
            tvStatus.text = "برای کشیدن نوار دور اشیا، اجازهٔ «نمایش روی برنامه‌های دیگر» را روشن کن. بعد برگرد و دوباره شروع را بزن. (یا تیک نوار دور اشیا را بردار)"
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
        } else if (Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            notifLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
        } else {
            askProjection()
        }
    }

    private fun askProjection() {
        val mpm = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        projLauncher.launch(mpm.createScreenCaptureIntent())
    }

    private fun showSelection() {
        val names = CocoClasses.NAMES
        val sel = prefs.selected
        val labels = names.map { CocoClasses.fa(it) }.toTypedArray()
        val checked = BooleanArray(names.size) { names[it] in sel }
        AlertDialog.Builder(this)
            .setTitle("چه چیزهایی اعلام شود؟")
            .setMultiChoiceItems(labels, checked) { _, which, isChecked -> checked[which] = isChecked }
            .setPositiveButton("ذخیره") { _, _ ->
                prefs.selected = names.filterIndexed { i, _ -> checked[i] }.toSet()
            }
            .setNegativeButton("لغو", null)
            .show()
    }

    private fun runTest() {
        testSpeaker?.shutdown()
        val beeper = Beeper(handler)
        beeper.beep(0f, 0.5f)
        handler.postDelayed({ beeper.beep(1f, 0.5f) }, 350)
        testSpeaker = Speaker(this) { persian ->
            tvStatus.text = if (persian) "صدای فارسی روی گوشی موجود است"
            else "صدای فارسی روی گوشی نصب نیست؛ انگلیسی خوانده می‌شود"
            testSpeaker?.speak(
                if (persian) "تست صدا. فرد، چپ. هواپیما، راست بالا"
                else "Voice test. person, left. airplane, top right"
            )
        }
    }
}
