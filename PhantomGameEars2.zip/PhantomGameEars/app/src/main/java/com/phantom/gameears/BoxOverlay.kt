package com.phantom.gameears

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.os.SystemClock
import android.view.View

data class Box(val l: Float, val t: Float, val r: Float, val b: Float, val label: String, val color: Int)

/** لایهٔ شفاف تمام‌صفحه که دور اشیای تشخیص‌داده‌شده کادر ضخیم و برچسب می‌کشد (لمس را رد می‌کند). */
class BoxOverlay(ctx: Context) : View(ctx) {
    @Volatile private var boxes: List<Box> = emptyList()
    @Volatile private var stamp = 0L
    private val d = ctx.resources.displayMetrics.density
    private val stroke = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = 5f * d
    }
    private val fill = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }
    private val text = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.BLACK
        textSize = 16f * d
        isFakeBoldText = true
    }

    fun set(list: List<Box>) {
        boxes = list
        stamp = SystemClock.uptimeMillis()
        postInvalidate()
    }

    override fun onDraw(c: Canvas) {
        val list = boxes
        if (list.isEmpty()) return
        if (SystemClock.uptimeMillis() - stamp > 1500) return
        val w = width.toFloat()
        val h = height.toFloat()
        for (b in list) {
            val l = b.l * w
            val t = b.t * h
            val r = b.r * w
            val bt = b.b * h
            stroke.color = b.color
            c.drawRect(l, t, r, bt, stroke)
            val tw = text.measureText(b.label)
            val th = text.textSize
            val ty = if (t - th - 8f * d > 0) t - 4f * d else bt + th + 4f * d
            fill.color = b.color
            c.drawRect(l, ty - th, l + tw + 12f * d, ty + 6f * d, fill)
            c.drawText(b.label, l + 6f * d, ty, text)
        }
        postInvalidateDelayed(400)
    }
}
