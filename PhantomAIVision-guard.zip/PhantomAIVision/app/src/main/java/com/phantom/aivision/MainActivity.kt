package com.phantom.aivision

import android.Manifest
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.Matrix
import android.graphics.RectF
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.*
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.camera.core.*
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.core.content.ContextCompat
import com.google.mediapipe.framework.image.BitmapImageBuilder
import com.google.mediapipe.framework.image.MPImage
import com.google.mediapipe.tasks.core.BaseOptions
import com.google.mediapipe.tasks.vision.core.RunningMode
import com.google.mediapipe.tasks.vision.objectdetector.ObjectDetectionResult
import com.google.mediapipe.tasks.vision.objectdetector.ObjectDetector
import com.google.android.gms.tasks.Tasks
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.face.FaceDetection
import com.google.mlkit.vision.face.FaceDetectorOptions
import java.util.concurrent.ExecutorService
import java.util.concurrent.atomic.AtomicBoolean
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt
import java.util.concurrent.Executors

class MainActivity : AppCompatActivity() {

    private lateinit var previewView: PreviewView
    private lateinit var overlay: OverlayView
    private lateinit var tvObjects: TextView
    private lateinit var tvPeople: TextView
    private lateinit var tvSelected: TextView
    private lateinit var tvAge: TextView
    private lateinit var tvBanner: TextView
    private lateinit var prefs: Prefs
    private lateinit var btnGuard: Button
    private lateinit var btnSiren: Button
    private lateinit var tvGuard: TextView

    // --- حالت نگهبان ---
    private lateinit var siren: SirenPlayer
    private val guardHandler = Handler(Looper.getMainLooper())
    private var guardActive = false
    private var guardArmAt = 0L
    private var sirenCooldownUntil = 0L
    private var personFrames = 0

    private var detector: ObjectDetector? = null
    private var modelError: String? = null
    private var cameraProvider: ProcessCameraProvider? = null

    // --- تخمین سن ---
    private var ageEstimator: AgeEstimator? = null
    private var ageError: String? = null
    private val faceDetector by lazy {
        FaceDetection.getClient(
            FaceDetectorOptions.Builder()
                .setPerformanceMode(FaceDetectorOptions.PERFORMANCE_MODE_FAST)
                .build()
        )
    }
    private val ageExecutor: ExecutorService = Executors.newSingleThreadExecutor()
    private val ageBusy = AtomicBoolean(false)
    private var lastAgeMs = 0L
    @Volatile private var norm255 = true
    private val ageHistory = HashMap<Int, ArrayDeque<Float>>()
    private var currentPersons: List<Pair<Int, RectF>> = emptyList()
    private val analysisExecutor: ExecutorService = Executors.newSingleThreadExecutor()
    private val tracker = PersonTracker()
    private val handler = Handler(Looper.getMainLooper())

    @Volatile private var running = false
    @Volatile private var threshold = 0.5f
    private var prevPresent: Set<String> = emptySet()

    private val palette = intArrayOf(
        0xFF8B5CF6.toInt(), 0xFF3B82F6.toInt(), 0xFF22D3EE.toInt(),
        0xFFEC4899.toInt(), 0xFFA78BFA.toInt(), 0xFF60A5FA.toInt()
    )

    private val permissionLauncher =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
            if (granted) startCamera() else disableGuard().also { showMessage(
                "دسترسی دوربین لازم است",
                "بدون مجوز دوربین برنامه کار نمی‌کند. می‌توانید از تنظیمات گوشی مجوز را فعال کنید."
            ) }
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        prefs = Prefs(this)
        threshold = prefs.threshold
        norm255 = prefs.norm255

        previewView = findViewById(R.id.previewView)
        overlay = findViewById(R.id.overlay)
        tvObjects = findViewById(R.id.tvObjects)
        tvPeople = findViewById(R.id.tvPeople)
        tvSelected = findViewById(R.id.tvSelected)
        tvAge = findViewById(R.id.tvAge)
        tvBanner = findViewById(R.id.tvBanner)
        btnGuard = findViewById(R.id.btnGuard)
        btnSiren = findViewById(R.id.btnSiren)
        tvGuard = findViewById(R.id.tvGuard)
        siren = SirenPlayer(this)
        btnGuard.setOnClickListener { toggleGuard() }
        btnSiren.setOnClickListener { stopSiren() }

        findViewById<Button>(R.id.btnStart).setOnClickListener { onStartClicked() }
        findViewById<Button>(R.id.btnStop).setOnClickListener { stopCamera() }
        findViewById<Button>(R.id.btnSelect).setOnClickListener { showSelectionDialog() }
        findViewById<Button>(R.id.btnSettings).setOnClickListener { showSettings() }

        createDetector()
        createAgeEstimator()
        updateSelectedText(emptyMap())
        updateAvgAge(emptyList(), 0)
    }

    private fun createDetector() {
        try {
            val options = ObjectDetector.ObjectDetectorOptions.builder()
                .setBaseOptions(BaseOptions.builder().setModelAssetPath(MODEL_FILE).build())
                .setRunningMode(RunningMode.LIVE_STREAM)
                .setMaxResults(15)
                .setScoreThreshold(0.3f)
                .setResultListener(this::onDetections)
                .setErrorListener(this::onDetectError)
                .build()
            detector = ObjectDetector.createFromOptions(this, options)
        } catch (e: Exception) {
            detector = null
            modelError = e.message
        }
    }

    private fun onStartClicked() {
        if (detector == null) {
            showMessage(
                "فایل مدل پیدا نشد",
                "فایل $MODEL_FILE را در app/src/main/assets/ قرار دهید (راهنما در README.md) و برنامه را دوباره بسازید.\n\n${modelError ?: ""}"
            )
            return
        }
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) {
            startCamera()
        } else {
            permissionLauncher.launch(Manifest.permission.CAMERA)
        }
    }

    private fun startCamera() {
        val future = ProcessCameraProvider.getInstance(this)
        future.addListener({
            try {
                val provider = future.get()
                cameraProvider = provider
                val preview = Preview.Builder().build()
                    .also { it.setSurfaceProvider(previewView.surfaceProvider) }
                val analysis = ImageAnalysis.Builder()
                    .setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST)
                    .setOutputImageFormat(ImageAnalysis.OUTPUT_IMAGE_FORMAT_RGBA_8888)
                    .build()
                analysis.setAnalyzer(analysisExecutor) { analyze(it) }
                provider.unbindAll()
                provider.bindToLifecycle(this, CameraSelector.DEFAULT_BACK_CAMERA, preview, analysis)
                running = true
            } catch (e: Exception) {
                showMessage("خطا در راه‌اندازی دوربین", e.message ?: "نامشخص")
            }
        }, ContextCompat.getMainExecutor(this))
    }

    private fun stopCamera() {
        disableGuard()
        running = false
        cameraProvider?.unbindAll()
        overlay.clear()
        tvObjects.text = "اشیا: ۰"
        tvPeople.text = "افراد: ۰"
        tvBanner.visibility = View.GONE
        prevPresent = emptySet()
        ageHistory.clear()
        currentPersons = emptyList()
        updateSelectedText(emptyMap())
        updateAvgAge(emptyList(), 0)
    }

    private fun analyze(proxy: ImageProxy) {
        val det = detector
        if (det == null || !running) { proxy.close(); return }
        val bmp: Bitmap
        try {
            val rotation = proxy.imageInfo.rotationDegrees
            val raw = Bitmap.createBitmap(proxy.width, proxy.height, Bitmap.Config.ARGB_8888)
            raw.copyPixelsFromBuffer(proxy.planes[0].buffer)
            bmp = if (rotation == 0) raw else {
                val m = Matrix().apply { postRotate(rotation.toFloat()) }
                Bitmap.createBitmap(raw, 0, 0, raw.width, raw.height, m, true)
            }
        } finally {
            proxy.close()
        }
        try {
            det.detectAsync(BitmapImageBuilder(bmp).build(), SystemClock.uptimeMillis())
            maybeEstimateAges(bmp)
        } catch (e: Exception) {
            runOnUiThread { showMessage("خطا در پردازش تصویر", e.message ?: "") }
        }
    }

    private data class Det(val name: String, val score: Float, val box: RectF)

    private fun onDetections(result: ObjectDetectionResult, input: MPImage) {
        val w = input.width
        val h = input.height
        val th = threshold
        val dets = result.detections().mapNotNull { d ->
            val c = d.categories().firstOrNull() ?: return@mapNotNull null
            if (c.score() < th) null else Det(c.categoryName(), c.score(), RectF(d.boundingBox()))
        }
        runOnUiThread { if (running) render(dets, w, h) }
    }

    private fun onDetectError(e: RuntimeException) {
        runOnUiThread { showMessage("خطای مدل", e.message ?: "") }
    }

    private fun colorFor(name: String) = palette[Math.floorMod(name.hashCode(), palette.size)]

    private fun render(dets: List<Det>, w: Int, h: Int) {
        val selected = prefs.selected
        val hideOthers = prefs.hideOthers
        val items = ArrayList<DrawItem>()

        val persons = dets.filter { it.name == "person" }
        val ids = tracker.update(persons.map { it.box })
        currentPersons = persons.mapIndexed { i, p -> ids[i] to RectF(p.box) }
        val shownAges = ArrayList<Float>()
        persons.forEachIndexed { i, p ->
            val pct = (p.score * 100).toInt()
            val age = ageHistory[ids[i]]?.takeIf { it.isNotEmpty() }?.average()?.toFloat()
            val ageText = if (age == null) "سن قابل تخمین نیست" else { shownAges.add(age); ageLabel(age) }
            items.add(DrawItem(p.box, "فرد #${ids[i]}  $pct٪  |  $ageText", 0xFF8B5CF6.toInt(), false))
        }

        val others = dets.filter { it.name != "person" }
        val selectedCounts = linkedMapOf<String, Int>()
        for (d in others) {
            if (d.name in selected) {
                val pct = (d.score * 100).toInt()
                items.add(DrawItem(d.box, "${CocoClasses.fa(d.name)} (${d.name}) $pct٪", colorFor(d.name), false))
                selectedCounts[d.name] = (selectedCounts[d.name] ?: 0) + 1
            } else if (!hideOthers) {
                items.add(DrawItem(d.box, null, 0x55FFFFFF, true))
            }
        }

        overlay.setItems(items, w, h)
        tvObjects.text = "اشیا: ${others.size}"
        tvPeople.text = "افراد: ${persons.size}  (یکتا: ${tracker.totalUnique})"
        updateSelectedText(selectedCounts)
        updateAvgAge(shownAges, persons.size)
        guardCheck(persons.size)

        val present = selectedCounts.keys.toSet()
        val entered = present - prevPresent
        if (entered.isNotEmpty()) {
            showBanner("✓ وارد تصویر شد: " + entered.joinToString("، ") { CocoClasses.fa(it) })
        }
        prevPresent = present
    }

    private fun updateSelectedText(counts: Map<String, Int>) {
        val sel = prefs.selected
        tvSelected.text = when {
            sel.isEmpty() -> "اشیای انتخاب‌شده: هیچ (از «انتخاب اشیا» استفاده کنید)"
            counts.isEmpty() -> "اشیای انتخاب‌شده (${sel.size}): در تصویر دیده نشد"
            else -> "اشیای انتخاب‌شده: " + counts.entries.joinToString("، ") { "${CocoClasses.fa(it.key)} ×${it.value}" }
        }
    }

    private fun showBanner(text: String) {
        tvBanner.text = text
        tvBanner.visibility = View.VISIBLE
        handler.removeCallbacksAndMessages(null)
        handler.postDelayed({ tvBanner.visibility = View.GONE }, 3000)
    }

    private fun showSelectionDialog() {
        val names = CocoClasses.NAMES
        val labels = names.map { "${CocoClasses.fa(it)}  ($it)" }.toTypedArray()
        val current = prefs.selected
        val checked = BooleanArray(names.size) { names[it] in current }
        val dlg = AlertDialog.Builder(this)
            .setTitle("انتخاب اشیا")
            .setMultiChoiceItems(labels, checked, null)
            .setPositiveButton("ذخیره", null)
            .setNeutralButton("انتخاب همه", null)
            .setNegativeButton("لغو انتخاب‌ها", null)
            .create()
        dlg.show()
        val lv = dlg.listView
        dlg.getButton(AlertDialog.BUTTON_NEUTRAL).setOnClickListener {
            for (i in names.indices) lv.setItemChecked(i, true)
        }
        dlg.getButton(AlertDialog.BUTTON_NEGATIVE).setOnClickListener {
            for (i in names.indices) lv.setItemChecked(i, false)
        }
        dlg.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener {
            prefs.selected = names.indices.filter { lv.isItemChecked(it) }.map { names[it] }.toSet()
            prevPresent = emptySet()
            updateSelectedText(emptyMap())
            dlg.dismiss()
        }
    }

    private fun showSettings() {
        val pad = (16 * resources.displayMetrics.density).toInt()
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad, pad, pad, pad)
        }
        val tv = TextView(this).apply { text = "حداقل اطمینان: ${(threshold * 100).toInt()}٪" }
        val sb = SeekBar(this).apply {
            max = 70
            progress = (threshold * 100).toInt() - 20
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) {
                    val t = (p + 20) / 100f
                    threshold = t; prefs.threshold = t
                    tv.text = "حداقل اطمینان: ${p + 20}٪"
                }
                override fun onStartTrackingTouch(s: SeekBar?) {}
                override fun onStopTrackingTouch(s: SeekBar?) {}
            })
        }
        val cb = CheckBox(this).apply {
            text = "پنهان کردن کادر اشیای انتخاب‌نشده"
            isChecked = prefs.hideOthers
            setOnCheckedChangeListener { _, c -> prefs.hideOthers = c }
        }
        val cbNum = CheckBox(this).apply {
            text = "نمایش سن تخمینی به‌صورت عدد"
            isChecked = prefs.showNumeric
            setOnCheckedChangeListener { _, c -> prefs.showNumeric = c }
        }
        val cbNorm = CheckBox(this).apply {
            text = "ورودی مدل سن: تقسیم بر ۲۵۵ (اگر سن‌ها غیرمنطقی‌اند، خاموش کنید)"
            isChecked = norm255
            setOnCheckedChangeListener { _, c -> norm255 = c; prefs.norm255 = c; ageHistory.clear() }
        }
        val clear = Button(this).apply {
            text = "پاک کردن داده‌های محلی"
            setOnClickListener {
                prefs.clear(); tracker.reset(); threshold = prefs.threshold; norm255 = prefs.norm255; ageHistory.clear()
                prevPresent = emptySet(); overlay.clear()
                updateSelectedText(emptyMap())
                Toast.makeText(this@MainActivity, "داده‌های محلی پاک شد", Toast.LENGTH_SHORT).show()
            }
        }
        val note = TextView(this).apply {
            text = "این برنامه هیچ تصویری را ذخیره یا ارسال نمی‌کند و مجوز اینترنت ندارد."
            textSize = 12f
        }
        listOf(tv, sb, cb, cbNum, cbNorm, clear, note).forEach {
            box.addView(it, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        }
        AlertDialog.Builder(this).setTitle("تنظیمات").setView(box).setPositiveButton("بستن", null).show()
    }

    private fun showMessage(title: String, msg: String) {
        if (isFinishing) return
        AlertDialog.Builder(this).setTitle(title).setMessage(msg).setPositiveButton("باشه", null).show()
    }

    override fun onDestroy() {
        super.onDestroy()
        running = false
        siren.stop()
        guardHandler.removeCallbacksAndMessages(null)
        handler.removeCallbacksAndMessages(null)
        cameraProvider?.unbindAll()
        analysisExecutor.shutdown()
        detector?.close()
        ageExecutor.shutdown()
        ageEstimator?.close()
        faceDetector.close()
    }

    // ===================== حالت نگهبان =====================

    private fun toggleGuard() {
        if (guardActive) { disableGuard(); return }
        if (detector == null) { onStartClicked(); return }
        guardActive = true
        guardArmAt = SystemClock.uptimeMillis() + ARM_DELAY_MS
        sirenCooldownUntil = 0L
        personFrames = 0
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        btnGuard.text = "غیرفعال کردن نگهبان"
        if (!running) onStartClicked()
        tickGuard()
    }

    private fun tickGuard() {
        guardHandler.removeCallbacksAndMessages(null)
        if (!guardActive || siren.isPlaying) return
        val left = guardArmAt - SystemClock.uptimeMillis()
        if (left > 0) {
            tvGuard.text = "🛡 نگهبان تا ${(left + 999) / 1000} ثانیه دیگر فعال می‌شود…"
            guardHandler.postDelayed({ tickGuard() }, 250)
        } else {
            tvGuard.text = "🛡 نگهبان فعال است — منتظر ورود فرد…"
        }
    }

    private fun guardCheck(personCount: Int) {
        if (!guardActive) return
        val now = SystemClock.uptimeMillis()
        if (now < guardArmAt || siren.isPlaying || now < sirenCooldownUntil) { personFrames = 0; return }
        personFrames = if (personCount > 0) personFrames + 1 else 0
        if (personFrames >= TRIGGER_FRAMES) triggerSiren()
    }

    private fun triggerSiren() {
        personFrames = 0
        guardHandler.removeCallbacksAndMessages(null)
        siren.start()
        btnSiren.visibility = View.VISIBLE
        tvGuard.text = "🚨 فرد تشخیص داده شد! آژیر روشن است"
    }

    private fun stopSiren() {
        siren.stop()
        btnSiren.visibility = View.GONE
        personFrames = 0
        if (guardActive) {
            sirenCooldownUntil = SystemClock.uptimeMillis() + COOLDOWN_MS
            tvGuard.text = "🛡 آژیر قطع شد؛ نگهبان بعد از ${COOLDOWN_MS / 1000} ثانیه دوباره آماده می‌شود"
        }
    }

    private fun disableGuard() {
        guardActive = false
        guardHandler.removeCallbacksAndMessages(null)
        siren.stop()
        btnSiren.visibility = View.GONE
        personFrames = 0
        window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        btnGuard.text = "فعال کردن نگهبان"
        tvGuard.text = "نگهبان: غیرفعال"
    }

    private fun createAgeEstimator() {
        try {
            ageEstimator = AgeEstimator(this)
        } catch (e: Exception) {
            ageEstimator = null
            ageError = e.message
        }
    }

    /** هر ~۷۰۰ میلی‌ثانیه یک‌بار: تشخیص چهره → برش → مدل سن. روی رشته جداگانه اجرا می‌شود. */
    private fun maybeEstimateAges(bmp: Bitmap) {
        val est = ageEstimator ?: return
        val now = SystemClock.uptimeMillis()
        if (now - lastAgeMs < 700 || !ageBusy.compareAndSet(false, true)) return
        lastAgeMs = now
        val norm = norm255
        ageExecutor.execute {
            try {
                val faces = Tasks.await(faceDetector.process(InputImage.fromBitmap(bmp, 0)))
                val out = ArrayList<Pair<RectF, Float>>()
                for (f in faces) {
                    val b = f.boundingBox
                    if (b.width() < MIN_FACE_PX || b.height() < MIN_FACE_PX) continue
                    if (abs(f.headEulerAngleY) > 30f || abs(f.headEulerAngleZ) > 25f) continue
                    val mx = (b.width() * 0.15f).toInt()
                    val my = (b.height() * 0.15f).toInt()
                    val l = max(0, b.left - mx)
                    val t = max(0, b.top - my)
                    val r = min(bmp.width, b.right + mx)
                    val bt = min(bmp.height, b.bottom + my)
                    if (r - l < MIN_FACE_PX || bt - t < MIN_FACE_PX) continue
                    val crop = Bitmap.createBitmap(bmp, l, t, r - l, bt - t)
                    val age = est.estimate(crop, norm)
                    if (crop !== bmp) crop.recycle()
                    if (age != null) out.add(RectF(b) to age)
                }
                runOnUiThread { if (running) onFaceAges(out) }
            } catch (e: Exception) {
                // خطای لحظه‌ای تشخیص چهره: این دور نادیده گرفته می‌شود
            } finally {
                ageBusy.set(false)
            }
        }
    }

    /** هر چهره را به کوچک‌ترین کادر فردی که مرکز چهره داخلش است نسبت می‌دهد و میانگین متحرک می‌گیرد. */
    private fun onFaceAges(faces: List<Pair<RectF, Float>>) {
        for ((fb, age) in faces) {
            val owner = currentPersons
                .filter { it.second.contains(fb.centerX(), fb.centerY()) }
                .minByOrNull { it.second.width() * it.second.height() } ?: continue
            val dq = ageHistory.getOrPut(owner.first) { ArrayDeque() }
            dq.addLast(age)
            if (dq.size > 6) dq.removeFirst()
        }
    }

    private fun ageLabel(age: Float): String {
        val cat = when {
            age < 13f -> "کودک"
            age < 20f -> "نوجوان"
            age < 60f -> "بزرگسال"
            else -> "سالمند"
        }
        return if (prefs.showNumeric) "$cat ~${age.roundToInt()} (تخمینی)" else "$cat (تخمینی)"
    }

    private fun updateAvgAge(ages: List<Float>, personCount: Int) {
        tvAge.text = when {
            ageEstimator == null ->
                "میانگین سن تخمینی: قابل تخمین نیست (فایل مدل سن پیدا نشد)"
            personCount == 0 -> "میانگین سن تخمینی: —"
            ages.isEmpty() -> "میانگین سن تخمینی: قابل تخمین نیست (چهره واضح دیده نشد)"
            else -> "میانگین سن تخمینی: ~${ages.average().roundToInt()} سال (از ${ages.size} نفر) — تخمینی است و ممکن است اشتباه باشد"
        }
    }

    companion object {
        const val MIN_FACE_PX = 80
        const val ARM_DELAY_MS = 10_000L
        const val COOLDOWN_MS = 15_000L
        const val TRIGGER_FRAMES = 3
        const val MODEL_FILE = "efficientdet_lite0.tflite"
    }
}
