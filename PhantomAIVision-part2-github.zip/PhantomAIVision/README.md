# PHANTOM AI VISION — بخش ۱ (دوربین + تشخیص اشیا + افراد + ردیابی)

## ۱) تهیه مدل (الزامی)
مدل EfficientDet-Lite0 (۸۰ کلاس COCO، مجوز Apache 2.0) از مخزن رسمی Google MediaPipe:

https://storage.googleapis.com/mediapipe-models/object_detector/efficientdet_lite0/float16/1/efficientdet_lite0.tflite

فایل را با همین نام دقیق اینجا بگذارید:

    app/src/main/assets/efficientdet_lite0.tflite

## ۲) اجرا
1. Android Studio (Koala یا جدیدتر) → File > Open → پوشه PhantomAIVision
2. صبر کنید Gradle Sync تمام شود (اینترنت لازم است). اگر درباره Gradle پرسید، Gradle 8.7 را بپذیرید.
3. گوشی را با USB Debugging وصل کنید و Run ▶ بزنید.

## ۳) ساخت APK
- آزمایشی: Build > Build Bundle(s) / APK(s) > Build APK(s)
  خروجی: app/build/outputs/apk/debug/app-debug.apk
- انتشار: Build > Generate Signed Bundle / APK > APK

## ۴) محدودیت‌ها
- تخمین سن هنوز پیاده‌سازی نشده (نیازمند مدل چهره + مدل سن، بخش ۲).
- ردیاب IoU در شلوغی شدید ممکن است شناسه را عوض کند.
- فقط ۸۰ کلاس COCO.


---
# بخش ۲ — تخمین سن

## مدل سن (الزامی برای این قابلیت)
از مخزن MIT: https://github.com/shubham0204/Age-Gender_Estimation_TF-Android
(پوشهٔ app/src/main/assets همان مخزن را بگردید) یکی از این فایل‌ها را بردارید و کنار مدل تشخیص اشیا بگذارید:

    model_age_nonq.tflite        (پیشنهادی: دقیق‌تر)
    model_age_q.tflite
    model_lite_age_nonq.tflite   (سریع‌تر، خطای بیشتر)
    model_lite_age_q.tflite

برنامه اولین فایل موجود را به همین ترتیب پیدا می‌کند. اگر فایل پیدا نشود، «سن قابل تخمین نیست» نشان می‌دهد.

## نکته مهم: نرمال‌سازی
مستندات مخزن نرمال‌سازی ورودی را مشخص نکرده‌اند. پیش‌فرض: تقسیم بر ۲۵۵.
اگر سن‌ها همیشه خیلی کم/زیاد یا ثابت بودند: تنظیمات ← گزینهٔ «تقسیم بر ۲۵۵» را خاموش کنید و دوباره امتحان کنید.

## رفتار
- هر ~۰٫۷ ثانیه چهره‌ها با ML Kit پیدا می‌شوند (بدون اینترنت).
- چهرهٔ کوچک (<۸۰ پیکسل) یا خیلی کج رد می‌شود → «سن قابل تخمین نیست».
- سن هر فرد میانگین ۶ تخمین اخیر است. این عددها تخمینی‌اند و ممکن است اشتباه باشند.
- UTKFace شرایط مجوز خودش را دارد؛ قبل از انتشار تجاری بررسی کنید.
