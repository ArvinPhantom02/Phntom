package com.phantom.aivision

import android.graphics.RectF

/** ردیاب ساده مبتنی بر IoU برای کاهش شمارش تکراری افراد در فریم‌های متوالی. */
class PersonTracker(private val iouThreshold: Float = 0.3f, private val maxMissed: Int = 8) {
    private class Track(val id: Int, var box: RectF, var missed: Int = 0)

    private val tracks = mutableListOf<Track>()
    private var nextId = 1

    val totalUnique: Int get() = nextId - 1

    fun reset() { tracks.clear(); nextId = 1 }

    /** برای هر جعبه ورودی، شناسه ردیابی را به همان ترتیب برمی‌گرداند. */
    fun update(boxes: List<RectF>): IntArray {
        val ids = IntArray(boxes.size)
        val used = HashSet<Track>()
        for ((i, b) in boxes.withIndex()) {
            var best: Track? = null
            var bestIou = iouThreshold
            for (t in tracks) {
                if (t in used) continue
                val v = iou(t.box, b)
                if (v > bestIou) { bestIou = v; best = t }
            }
            if (best == null) {
                best = Track(nextId++, RectF(b)); tracks.add(best)
            } else {
                best.box = RectF(b); best.missed = 0
            }
            used.add(best)
            ids[i] = best.id
        }
        val it = tracks.iterator()
        while (it.hasNext()) {
            val t = it.next()
            if (t !in used) { t.missed++; if (t.missed > maxMissed) it.remove() }
        }
        return ids
    }

    private fun iou(a: RectF, b: RectF): Float {
        val l = maxOf(a.left, b.left); val t = maxOf(a.top, b.top)
        val r = minOf(a.right, b.right); val bt = minOf(a.bottom, b.bottom)
        val inter = maxOf(0f, r - l) * maxOf(0f, bt - t)
        val union = a.width() * a.height() + b.width() * b.height() - inter
        return if (union <= 0f) 0f else inter / union
    }
}
