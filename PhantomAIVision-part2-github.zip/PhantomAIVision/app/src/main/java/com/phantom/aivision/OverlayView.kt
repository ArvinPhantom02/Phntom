package com.phantom.aivision

import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.RectF
import android.util.AttributeSet
import android.view.View

data class DrawItem(val box: RectF, val label: String?, val color: Int, val thin: Boolean)

class OverlayView(context: Context, attrs: AttributeSet? = null) : View(context, attrs) {
    private var items: List<DrawItem> = emptyList()
    private var imgW = 1
    private var imgH = 1
    private val d = resources.displayMetrics.density

    private val boxPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE }
    private val bgPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }
    private val textPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = 0xFFFFFFFF.toInt(); textSize = 13f * d; isFakeBoldText = true
    }

    fun setItems(newItems: List<DrawItem>, w: Int, h: Int) {
        items = newItems; imgW = w; imgH = h; invalidate()
    }

    fun clear() { items = emptyList(); invalidate() }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        if (items.isEmpty()) return
        // PreviewView به‌صورت پیش‌فرض FILL_CENTER است
        val scale = maxOf(width.toFloat() / imgW, height.toFloat() / imgH)
        val dx = (width - imgW * scale) / 2f
        val dy = (height - imgH * scale) / 2f
        for (item in items) {
            val r = RectF(
                item.box.left * scale + dx, item.box.top * scale + dy,
                item.box.right * scale + dx, item.box.bottom * scale + dy
            )
            boxPaint.color = item.color
            boxPaint.strokeWidth = (if (item.thin) 1f else 3f) * d
            canvas.drawRoundRect(r, 6f * d, 6f * d, boxPaint)
            val label = item.label ?: continue
            val tw = textPaint.measureText(label)
            val th = textPaint.textSize
            val top = (r.top - th - 8f * d).coerceAtLeast(0f)
            bgPaint.color = item.color
            canvas.drawRect(r.left, top, r.left + tw + 12f * d, top + th + 8f * d, bgPaint)
            canvas.drawText(label, r.left + 6f * d, top + th + 1f * d, textPaint)
        }
    }
}
