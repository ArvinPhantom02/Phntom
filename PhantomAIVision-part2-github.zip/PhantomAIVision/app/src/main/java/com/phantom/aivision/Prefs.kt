package com.phantom.aivision

import android.content.Context

class Prefs(ctx: Context) {
    private val sp = ctx.getSharedPreferences("phantom_prefs", Context.MODE_PRIVATE)

    var selected: Set<String>
        get() = sp.getStringSet("selected", emptySet())!!.toSet()
        set(v) { sp.edit().putStringSet("selected", v).apply() }

    var threshold: Float
        get() = sp.getFloat("threshold", 0.5f)
        set(v) { sp.edit().putFloat("threshold", v).apply() }

    var hideOthers: Boolean
        get() = sp.getBoolean("hideOthers", false)
        set(v) { sp.edit().putBoolean("hideOthers", v).apply() }

    var showNumeric: Boolean
        get() = sp.getBoolean("showNumeric", true)
        set(v) { sp.edit().putBoolean("showNumeric", v).apply() }

    var norm255: Boolean
        get() = sp.getBoolean("norm255", true)
        set(v) { sp.edit().putBoolean("norm255", v).apply() }

    fun clear() { sp.edit().clear().apply() }
}
