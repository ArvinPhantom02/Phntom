package com.phantom.aivision

import android.content.Context
import android.graphics.Bitmap
import org.tensorflow.lite.DataType
import org.tensorflow.lite.Interpreter
import java.io.Closeable
import java.io.FileInputStream
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.nio.channels.FileChannel

/**
 * تخمین سن از تصویر برش‌خورده چهره با مدل TFLite (پروژه MIT: shubham0204/Age-Gender_Estimation_TF-Android).
 * ورودی: RGB با اندازه‌ای که از خود مدل خوانده می‌شود (۲۰۰×۲۰۰). خروجی: عدد ۰..۱ که در ۱۱۶ ضرب می‌شود.
 * فقط از یک رشته (thread) استفاده شود.
 */
class AgeEstimator(context: Context) : Closeable {

    private val interpreter: Interpreter
    private val inW: Int
    private val inH: Int
    private val inType: DataType
    private val outType: DataType
    private val outScale: Float
    private val outZero: Int
    private val outBytes: Int
    val modelName: String

    init {
        val name = context.assets.list("")?.firstOrNull { it in CANDIDATES }
            ?: throw IllegalStateException("هیچ‌کدام از فایل‌های ${CANDIDATES.joinToString()} در assets نیست")
        modelName = name
        val afd = context.assets.openFd(name)
        val mapped = FileInputStream(afd.fileDescriptor).channel
            .map(FileChannel.MapMode.READ_ONLY, afd.startOffset, afd.declaredLength)
        interpreter = Interpreter(mapped, Interpreter.Options().setNumThreads(2))

        val inT = interpreter.getInputTensor(0)
        val shape = inT.shape() // [1, h, w, 3]
        require(shape.size == 4 && shape[3] == 3) { "شکل ورودی مدل ناسازگار است: ${shape.joinToString()}" }
        inH = shape[1]; inW = shape[2]
        inType = inT.dataType()
        require(inType == DataType.FLOAT32 || inType == DataType.UINT8) { "نوع ورودی پشتیبانی نمی‌شود: $inType" }

        val outT = interpreter.getOutputTensor(0)
        outType = outT.dataType()
        require(outType == DataType.FLOAT32 || outType == DataType.UINT8) { "نوع خروجی پشتیبانی نمی‌شود: $outType" }
        outScale = outT.quantizationParams().scale
        outZero = outT.quantizationParams().zeroPoint
        outBytes = outT.numBytes()
    }

    /** سن تخمینی به سال، یا null اگر نتیجه نامعتبر باشد. */
    fun estimate(face: Bitmap, divideBy255: Boolean): Float? {
        val scaled = Bitmap.createScaledBitmap(face, inW, inH, true)
        val px = IntArray(inW * inH)
        scaled.getPixels(px, 0, inW, 0, 0, inW, inH)
        if (scaled !== face) scaled.recycle()

        val perChannel = if (inType == DataType.FLOAT32) 4 else 1
        val input = ByteBuffer.allocateDirect(inW * inH * 3 * perChannel).order(ByteOrder.nativeOrder())
        for (p in px) {
            val r = (p shr 16) and 0xFF
            val g = (p shr 8) and 0xFF
            val b = p and 0xFF
            if (inType == DataType.FLOAT32) {
                if (divideBy255) {
                    input.putFloat(r / 255f); input.putFloat(g / 255f); input.putFloat(b / 255f)
                } else {
                    input.putFloat(r.toFloat()); input.putFloat(g.toFloat()); input.putFloat(b.toFloat())
                }
            } else {
                input.put(r.toByte()); input.put(g.toByte()); input.put(b.toByte())
            }
        }
        input.rewind()

        val out = ByteBuffer.allocateDirect(outBytes).order(ByteOrder.nativeOrder())
        interpreter.run(input, out)
        out.rewind()
        val raw = if (outType == DataType.FLOAT32) out.float
        else ((out.get().toInt() and 0xFF) - outZero) * outScale
        val age = raw * AGE_SCALE
        return if (age.isNaN() || age < 0f || age > 120f) null else age
    }

    override fun close() { interpreter.close() }

    companion object {
        const val AGE_SCALE = 116f
        /** به ترتیب اولویت؛ اولین فایل موجود در assets استفاده می‌شود. */
        val CANDIDATES = listOf(
            "model_age_nonq.tflite", "model_age_q.tflite",
            "model_lite_age_nonq.tflite", "model_lite_age_q.tflite",
            "age_model.tflite"
        )
    }
}
